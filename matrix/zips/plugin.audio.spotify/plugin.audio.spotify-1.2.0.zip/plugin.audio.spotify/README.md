# plugin.audio.spotify
Unofficial spotify plugin for Kodi, (for now) not yet available in the official Kodi repo.

Based on the opensource Librespot client. Special thanks to mherger for building the special spotty binaries, based on librespot.

This a fork of [marcelveldt](https://github.com/marcelveldt) version modified to make it work with Kodi 19.

## Support
create issue in Github
