# Kodi Plugin Audiothek Browser

[1]: https://kodi.tv/
[2]: https://www.ardaudiothek.de/

Dieses [Kodi Mediacenter][1] plugin erlaubt es die Inhalte der [ARD Audiothek][2] direkt in Kodi zu durchsuchen und abzuspielen. Alle Daten (Audiodateien, Bilder, Icon) werden nicht gespeichert, sondern verlinken die ARD Audiothek.

Das Plugin kann über diese [Repository](https://codingPF.github.io/repository.codingPF/) installiert werden.

Viel Spaß
