# Kodi Plugin News App

[1]: https://kodi.tv/
[2]: https://www.tagesschau.de/
[3]: https://www.zdf.de/nachrichten/

Dieses [Kodi Mediacenter][1] plugin erlaubt es die Inhalte der [Tagesschau App][2] & der [ZDF Heute App][3] direkt in Kodi zu durchsuchen und abzuspielen. Alle Daten (Audiodateien, Bilder, Icons) werden nicht gespeichert, sondern von der Webseite des Betreibers bedient.

Viel Spaß
